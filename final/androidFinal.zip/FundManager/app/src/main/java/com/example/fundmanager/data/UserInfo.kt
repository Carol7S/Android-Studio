package com.example.fundmanager.data

data class UserInfo (var username:String, var password:String, var permission:String)