package com.example.fundmanager.data

data class FundInfo(var name:String, var value:String, var size:String, var time:String, var DailyIncrease:String, var WeeklyIncrease:String, var MonthlyIncrease:String, var YearlyIncrease:String, var holdNum:Int)
