## 使用说明

1. 把 AndroidServer 拖入 idea。
2. 把 FundManager 拖入 android studio （我是用mac写的，如果win上出现问题，谷歌解决）。
3. 打开mysql服务
4. 运行sql文件，导入数据库
5. 运行idea
6. android studio 里修改 server_ip 为你的ip（不能是127.0.0.1和localhost）（有多个文件，都要改）
7. 运行android studio