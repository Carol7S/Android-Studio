package com.example.test1

data class TrainInfo(val name:String, val startStation:String, val endStation:String, val startTime:String, val endTime:String, var shangWu:Int, var firstNumber:Int, var secondNumber:Int, var wuZuo:Int)
// data =
// toString
// equals
// get/set